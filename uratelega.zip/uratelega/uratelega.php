<?php
/**
 * @package Polakov
 * @version 1.0
 */
/*
Plugin Name: Ура! Телеграм
Plugin URI: http://bigdatamicrodata.pp.ua
Description: Ура! Телеграм 
Armstrong: My Plugin.
Author: Сергей Поляков
Version: 1.0
Author URI: http://bigdatamicrodata.pp.ua
*/

 error_reporting(0);
 


// mt_options_page() displays the page content for the Test Options submenu
function polakov_options_page() 
{
	echo "<h2>Настройка отправки уведомлений в Телеграмм</h2>";
	echo "<p>Автор плагина: Сергей Поляков </p>";	
	  
	//Изменение информации о боте
	echo "<h3>Вставьте API своего телеграм бота, например 649278391:AAFpljZPfih1I7zocwZRV3BEL9zbpUkGkMw</h3>
	<p>1. Создайте канал или группу в Телеграм</p>
<p>2. Найдите бота @BotFather (набрать @BotFather)</p>
<p>3. Запустите его командой /start в окне диалога с @BotFather</p>
<p>4. Создайте вашего бота командой /newbot в окне диалога @BotFather</p>
<p>5. Дайте имя боту, добавьте указание _bot </p>
<p>6. После создания бота скопируйте данные которые вы получите в соответствующие поля настроек плагина — API бота</p> 
<p>7. @userinfobot возвращает значение chat_id </p> 
<p>8. @ShowJsonBot возвращает чуть больше информации</p> 
	";
	polakov_change_product();	
}
 
//Изменение информации о боте
function polakov_change_product()
{
	global $wpdb;
	$table_products = $wpdb->prefix.polakov_products;
	
	//Сохранение изменений ботов
	if ( isset($_POST['setup_btn']) ) 
    {    
		$name = $_POST['name'];   
		echo $name;
		$chat_id = $_POST['chat_id'];   
		echo $chat_id;
		$wpdb->get_results("UPDATE $table_products SET `name` = '$name', `chat_id` = '$chat_id' ");
    } 
	
	//Вывод формы информации по ботам
	$products = $wpdb->get_results("SELECT * FROM $table_products");
	foreach ($products as $item) 	
	{ 
		echo
		"<form method='post' id='sendform' enctype='multipart/form-data'> 
			<table>
				 
				<tr>
					<td style='text-align:right;'>API бота:</td>
					<td><input type='text' name='name' value='".$item->name."' style='width:400px;'/></td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td style='text-align:right;'>Chat id:</td>
					<td><input type='text' name='chat_id' value='".$item->chat_id."' style='width:400px;'/></td>
					<td>&nbsp;</td>
				</tr>
				 
				<tr>
					<td>&nbsp;</td>
					<td>
						<input type='submit' name='setup_btn' value='Сохранить' style='width:140px; height:25px'/>
						 
					</td>
				</tr>
			</table>
		</form>
		";
	}
}
 

function start_download1()
{
	global $wpdb;
	
	 
	if($code_product)
	{	
		$product_code_id = $code_product->product_id;
		
		$product = $wpdb->get_row
		(  
			$wpdb->prepare
			(  
				"SELECT * FROM $table_products ", 
				$product_code_id
			)
		);
		
		$url = $product->url;
		
		download_file1($url);
	}
	else
	{
		echo "Ссылка не активна";
	}
}
  

function polakov_install()
{
    global $wpdb;
	
	$table_products = $wpdb->prefix.polakov_products;
	 
    
	$sql2 =
	"
		CREATE TABLE IF NOT EXISTS `".$table_products."` (
		  `name` varchar(250) NOT NULL,
		  `chat_id` varchar(250) NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=utf8; 
	";
	$sql23 =
	"
		INSERT INTO `".$table_products."` (
			`name`
			)
			VALUES (
			'TEST'
			);
	";

	 
	$wpdb->query($sql2);
	$wpdb->query($sql23);
	 
}

function polakov_uninstall()
{
    global $wpdb;
	
	$table_products = $wpdb->prefix.polakov_products; 
	
    $sql1 = "DROP TABLE `".$table_products."`;"; 
	
    $wpdb->query($sql1); 
}

function polakov_add_admin_pages() 
{
    // Add a new submenu under Options:
    add_menu_page('Ура! телега!', 'Ура! телега!', 8, 'uratelega', 'polakov_options_page');
	//	wp_register_script('advReviewsAdminJs', $this->plugin_url . 'uratelega.js' );
	//	 wp_enqueue_script('advReviewsAdminJs');
	global $wpdb;
	
	$table_products = $wpdb->prefix.polakov_products; 
	 
	$product = $wpdb->get_row
		(  
			  
				"SELECT * FROM $table_products " 
			 
		);
		
		$rowname = $product->name;
		$rowchat_id = $product->chat_id;
//	echo $rowname;  
//	echo $rowchat_id; 
	//'.$row1['name'].'
	echo "
	 <script src=https://wikirip.site/js/jquery-2.1.1.min.js></script>
	<script>
		$(document).ready(function() {
		 setTimeout(function () {
                       $('#editor > div > div > div.components-navigate-regions > div > div.block-editor-editor-skeleton__header > div > div.edit-post-header__settings').append('<p><input id=tel type=checkbox /> <label for=tel>Отправить уведомление на Телеграмм</label> </p>'); 
					   $('#editor > div > div > div.components-navigate-regions > div > div.block-editor-editor-skeleton__header > div > div.edit-post-header__settings > button.components-button.editor-post-publish-button.editor-post-publish-button__button.is-primary').click(function() {
							//alert('tel click');
							if($('#tel').is(':checked')){ 
								//alert('tel checked');
								$.ajax({
									url: 'https://api.telegram.org/bot$rowname/sendMessage?chat_id=$rowchat_id&text=У вас изменили статью',
									type: 'post',
									dataType: 'json' 
								}); 
							 }
						}); 
                    }, 1000);

		}); 
		
	</script>";
}
register_activation_hook( __FILE__, 'polakov_install');
register_deactivation_hook( __FILE__, 'polakov_uninstall');

add_action('admin_menu', 'polakov_add_admin_pages'); 

?>
